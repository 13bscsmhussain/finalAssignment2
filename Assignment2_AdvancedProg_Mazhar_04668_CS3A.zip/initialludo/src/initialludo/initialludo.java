/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package initialludo;
import java.io.*;
import java.util.*;

/**
 *
 * @author Mazhar Hussain Awan
 */




public class initialludo {
	
public static int   snakeschanges(int [ ] array1, int[] array2, int currentscore)  //function to check positions of players whether they are on mouth of snake
{
	for(int i=0; i<array1.length; i++){ //array1 is array of snake mouths
		if (array1[i] == currentscore){ //currentscore is current value or position of person on board
			currentscore = array2[i];	//decrementing the position of current player to tail of snake
		}
	}	
	return currentscore;
}




public static int   ladderchanges(int [ ] array1, int[] array2, int currentscore) //function to check for position of players as if they are at start of ladder
{
	for(int i=0; i<array1.length; i++){ //array1 is start of ladder
		if (array1[i] == currentscore){
			currentscore = array2[i];	//array2 has values of each laddre's end
		}
	}	
	return currentscore;
}



public static int game(){ 	//function where whole logic of game lies
	
	int[] a= new int [100];	//initializing the board
	int[] rounds;			//rounds are basically count of dice rolled
	
	for(int i=0; i<100; i++){
		a[i] = i+1;
	}
	
	Queue<Integer>playersqueue = new LinkedList<Integer>(); //used queue to assign players their turn
	
	int[] snakemouth = {22, 36, 50, 76, 98}; //array containing positions where snake has mouth
	int[] snaketail =  {14, 29, 41, 68, 17}; //array containing positions where snake has tail
	
	
	int[] ladderstart = {9, 26, 64, 79}; //array containing positions where ladder has start
	int[] ladderend =    {16, 39, 69, 94}; //array containing positions where ladder has end
	
	
	
	
	//generating a random number between 2 and 4
	
	
	int min1 = 2;
	int max1 = 5;
	int players = (int)(Math.random()*(max1-min1))+min1; //random number of players
	System.out.print("Total Players...");
	System.out.print(players);
	
	int[] snakebite = new int[players];
	int[] playersindex = new int[players]; //array to store current positions of players
	rounds = new int[players];
	for (int i=0; i<players; i++){
		
		playersindex[i] = 1; //initial position of  a person
		snakebite[i]=0;
		playersqueue.add(i); //adding first player to the queue
		rounds[i] = 0;
	}
	System.out.print("\n");

	//System.out.print(playersqueue.remove());
	//System.out.print(playersqueue.remove());
	
	int secondthrow=0; //variable for second throw of dice
	int wincondintion = 0; //variable to check wining conditions
	int recentplayer=0; //variable for current player
	
	
	
	while(wincondintion!=1){ //loop until no player wins
		System.out.print("\n");

		if(secondthrow==0){
		recentplayer = playersqueue.remove();// removing current player from the queue
		rounds[recentplayer]+=1;
		System.out.print("\n");
		System.out.print("Turn of player:");
		System.out.print(recentplayer);
		System.out.print("\n");

		}
		 
		//generating random number for value of dice
		int min=1;
		int max=7;
		int dicenum = (int) (Math.random() * (max - min)) + min;
		System.out.print("Dice value:");
		System.out.print(dicenum);
		System.out.print("\n");
		secondthrow = 0;
		
		if(playersindex[recentplayer]+dicenum<100 && dicenum == 6){ //checking if current location of player is less than 100 and dice resulted in a six
				
			snakebite[recentplayer]=0; 
		}
		
		
		if(playersindex[recentplayer]+dicenum<100){
		
		if(snakebite[recentplayer]==0){	 //if snake has not bitten the person 
		playersindex[recentplayer] += dicenum; //then add his current value to his current position
		
		System.out.print(playersindex[recentplayer]);
		System.out.print("\n");
		
		
		if(dicenum==6){ //if a player gets a six
			secondthrow  =1; //then he gets another chance to throw the dice
		}
		
		
		
		
		int modifiedscore = snakeschanges( snakemouth, snaketail, playersindex[recentplayer]); //calling snakechange function to get modified position of a player
		
		if(modifiedscore!=playersindex[recentplayer]){
		playersindex[recentplayer]= modifiedscore; //if snake has bitten then change position of player to down new position
		snakebite[recentplayer] = 1;
		System.out.print("Snake Bitten:");
		System.out.print(playersindex[recentplayer]);
		}
		else{
			snakebite[recentplayer] = 0;
		}
		
		int modifiedladder = ladderchanges(ladderstart, ladderend, playersindex[recentplayer]); //calling ladderchange function to check whether if player has climbed a ladder

		if(modifiedladder!=playersindex[recentplayer]){
			playersindex[recentplayer]= modifiedladder; //if ladder comes then climb it
			System.out.print("Ladder Climb:");
			System.out.print(playersindex[recentplayer]);
			secondthrow  =1;
			}
			

		
		}
		}
		
		
		
		
				
		if(playersindex[recentplayer]+dicenum >100 ){ //checking if player's current position and dice number results in a number greater than 100
			secondthrow =0; //then do not assign him  second chance
		
		}
		
		if(playersindex[recentplayer]+dicenum ==100 && dicenum==6 ){ //if current position and a six resulted in 100
			secondthrow =0; //he has no second chance
		}
		
		if(playersindex[recentplayer]+dicenum ==100 && dicenum==6 && secondthrow ==1){
			secondthrow =0;
		}
		
		if(secondthrow==0){
			playersqueue.add(recentplayer); //if player has no second chance add second player to the queue

		}
		if(playersindex[recentplayer]+dicenum ==100 && dicenum!=6 && secondthrow==0){ //if current dice results in a 100 and he has no second chance then he wins
			wincondintion =1;
			
		}
		
	}
	
	System.out.print("\nYou won Player:");
	System.out.print(recentplayer+"\n");
	
	return rounds[recentplayer];
	
	
	
}

public static void main(String args[]){
	
	int i = 0;
	int totalrounds[]; //array to calculate rounds in 100 games
	totalrounds = new int[100];
	while(i<100){
		
		totalrounds[i]=game();		 
	
	
		i++;
	}
	
	for(int j=0;j<100;j++){
		System.out.println(totalrounds[j]);
	}
	
	
	 Arrays.sort(totalrounds); //sorting array to find maximum and minimum value of rounds in 100 games
	 int max = totalrounds[totalrounds.length - 1];
	 System.out.print("\nMaximum Rounds:"+max);
	 System.out.println("\nMinimum Rounds: "+totalrounds[0]);
	 int sum = 0;
	 for (int k = 0; k < totalrounds.length; k++){
	      sum = sum + totalrounds[k];
	 }
	    // calculate average
	 double average = sum / totalrounds.length;

	 System.out.println("\nAverage: " + average); //average rounds of 100 games

	
}	

}
