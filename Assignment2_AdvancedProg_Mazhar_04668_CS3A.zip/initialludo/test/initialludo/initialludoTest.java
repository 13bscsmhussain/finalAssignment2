/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package initialludo;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Mazhar Hussain Awan
 */
public class initialludoTest {
    
    

    /**
     * Test of snakeschanges method, of class initialludo.
     */
    
     @Test
    public void testSnakesCheck() {
        System.out.println("snakes condition checks:");
        int currentPosition = 0;

        int[] snakesmouth;
        int[] snaketail;
        
        snakesmouth = new int[5];
        snaketail = new int[5];
        
        snakesmouth[0] = 22;
        snaketail[0] = 14;
        snakesmouth[1] = 36;
        snaketail[1] = 29;
        snakesmouth[2] = 50;
        snaketail[2] = 41;
        snakesmouth[3] = 76;
        snaketail[3] = 68;
        snakesmouth[4] = 98;
        snaketail[4] = 17;
        

        
        //checking snakes whether working properly or not
        currentPosition = 22;

        
        int expected = 14;

        int result = initialludo.snakeschanges(snakesmouth, snaketail, currentPosition);
        assertEquals(expected, result);

        

    }

    
    /**
     * Test of ladderchanges method, of class initialludo.
     */
    
     @Test
    public void testLaddersCheck() {
        System.out.println("ladders condition checks:");
        int currentPosition1 = 0;

        int[] ladderstart;
        int[] ladderend;
        
        ladderstart = new int[5];
        ladderend = new int[5];
        
        ladderstart[0] = 9;
        ladderend[0] = 16;
        ladderstart[1] = 26;
        ladderend[1] = 39;
        ladderstart[2] = 64;
        ladderend[2] = 69;
        ladderstart[3] = 79;
        ladderend[3] = 94;
        
        //checking ladders whether working properly or not
        currentPosition1 = 9;

        
        int expected = 16;

        int result = initialludo.ladderchanges(ladderstart, ladderend, currentPosition1);
        assertEquals(expected, result);
    }
    
    @Test(timeout=1000)
   public void testPrintMessage() {	
      System.out.println("Inside game func:");     
      initialludo.game();     
   }
    
    
    
    
}
